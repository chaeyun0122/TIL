package aop001;

// 여자의 생활
public class Girl {
	public void runSomething() {
		System.out.println("문을 열고 집에 들어간다.");
		
		try {
			System.out.println("넷플릭스를 본다.");
		}catch(Exception e) {
			if(e.getMessage().equals("불")) {
				System.out.println("119에 신고한다.");
			}
		}finally {
			System.out.println("불을 끄고 잔다.");
		}
		System.out.println("문을 잠그고 집을 나온다.");
	}
}
