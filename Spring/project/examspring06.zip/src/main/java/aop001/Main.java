package aop001;

public class Main {
	public static void main(String[] args) {
		Boy romeo = new Boy();
		Girl juliet = new Girl();
		
		romeo.runSomething();
		System.out.println();
		juliet.runSomething();
	}
}
