package aop013;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {
	public static void main(String[] args) {
		ApplicationContext ctx =
				new ClassPathXmlApplicationContext("aop013.xml");
		
		Person romeo = ctx.getBean("boy", Person.class);
		Person juliet = ctx.getBean("girl", Person.class);
		try {
			romeo.runSomething();
		} catch(Exception e) {
			
		}
		System.out.println();
		juliet.runSomething();
	}
}
