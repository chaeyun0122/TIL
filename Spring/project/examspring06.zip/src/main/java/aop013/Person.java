package aop013;

public interface Person {
	public void runSomething();
}
