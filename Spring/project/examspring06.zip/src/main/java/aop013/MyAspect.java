package aop013;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;

@Aspect
public class MyAspect {
	
	@Pointcut("execution(* runSomething())")
	public void pc() {}
	
	@Before("pc()")
	public void OpenIn(JoinPoint jp) {
		System.out.println("문을 열고 집에 들어간다.");
	}
	
	@After("pc()")
	public void LockOut(JoinPoint jp) {
		System.out.println("문을 잠그고 집을 나간다.");
	}
	
	// around 적용 메서드 (호출 시점을 메서드 내에서 지정)
	// ProceedingJoinPoint : 핵심 메서드를 호출하는 기능을 가짐
//	@Around("pc()")
//	public void life(ProceedingJoinPoint pjp) { 
//		System.out.println("밥을 먹는다."); // before
//		
//		try {
//			pjp.proceed();  			// 핵심 메서드가 호출되는 시점
//			System.out.println("??");
//		} catch (Throwable e) {
//			e.printStackTrace();
//		} 					
//		
//		System.out.println("씻고 잔다.");  // after
//	}
	
	// AfterReturning 적용 메서드 (핵심 기능 정상 종료 시)
	@AfterReturning("pc()")
	public void finishLife() {
		System.out.println("오늘의 주요 할 일 종료!");
	}
	
	// AfterThrowing 적용 메서드 (핵심 기능 동작 시 예외가 발생된 경우)
	@AfterThrowing("pc()")
	public void fire() {
		System.out.println("119에 신고!");
	}
}
