package aop005;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;

@Aspect
public class MyAspect {
	@Before("execution(* runSomething())")
	public void OpenIn(JoinPoint jp) {
		System.out.println("문을 열고 집에 들어간다.");
	}
	
	@After("execution(* runSomething())")
	public void LockOut(JoinPoint jp) {
		System.out.println("문을 잠그고 집을 나간다.");
	}
}
