package aop005;

public interface Person {
	public void runSomething();
}
