package aop01;

public interface Calculator {
	public long factorial(long n);
}
