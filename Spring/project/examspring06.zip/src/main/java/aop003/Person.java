package aop003;

public interface Person {
	public void runSomething();
}
