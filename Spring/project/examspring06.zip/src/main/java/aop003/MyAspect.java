package aop003;

import org.aspectj.lang.JoinPoint;

// POJO 클래스
public class MyAspect {
	public void before(JoinPoint jp) {
		System.out.println("문을 열고 집에 들어간다.");
	}
}
