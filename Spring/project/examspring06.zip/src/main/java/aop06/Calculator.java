package aop06;

public interface Calculator {
	public long factorial(long n);
}
