package aop012;

public interface Person {
	public void runSomething();
}
