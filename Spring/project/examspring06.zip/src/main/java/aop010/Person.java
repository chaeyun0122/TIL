package aop010;

public interface Person {
	public void runSomething();
}
