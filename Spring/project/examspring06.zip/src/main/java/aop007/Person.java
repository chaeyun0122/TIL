package aop007;

public interface Person {
	public void runSomething();
}
