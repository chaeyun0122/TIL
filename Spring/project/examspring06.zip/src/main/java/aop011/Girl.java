package aop011;

// 여자의 생활
public class Girl implements Person{
	public void runSomething() {
		System.out.println("넷플릭스를 본다.");
	}
}
