package aop011;

public interface Person {
	public void runSomething();
}
