package aop011;

// 남자의 생활
public class Boy implements Person{
	public void runSomething() {
		System.out.println("컴퓨터로 게임을 한다.");
	}
}
