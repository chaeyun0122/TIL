package aop00;

public interface Calculator {
	public long factorial(long n);
}
