package exam01;

public class 출금 {
	public void process() {
		System.out.println("출금되었습니다.");
	}
}
