package exam01;

public class Ex01 {
	public static void main(String[] args) {
		입금 in = new 입금();
		출금 out = new 출금();
		
		in.process();
		out.process();
	}
}
