package exam01;

public class 입금 {
	public void process() {
		System.out.println("입금되었습니다.");
	}
}
