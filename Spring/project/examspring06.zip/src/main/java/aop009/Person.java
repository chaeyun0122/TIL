package aop009;

public interface Person {
	public void runSomething();
}
