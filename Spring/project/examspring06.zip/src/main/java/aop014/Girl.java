package aop014;
//여자의 생활
public class Girl implements Person{
	public void runSomething() {
		System.out.println("요리를 한다.");
	}
}
