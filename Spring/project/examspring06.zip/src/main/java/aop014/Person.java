package aop014;

public interface Person {
	public void runSomething();
}
