package aop014;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;

//POJO 클래스
@Aspect
public class MyAspect {
	
	@Pointcut("execution(* runSomething())")
	public void pc() {}
	
	//around적용 메서드(호출 시점을 메서드 내에서 지정)
	@Around("pc()")
	public void life(ProceedingJoinPoint pjp) {
		System.out.println("문을 열고 집에 들어간다.");
		try {
			System.out.println("밥을 먹는다");
			pjp.proceed(); //핵심 메서드가 호출되는 시점!
			System.out.println("오늘의 주요 할 일 종료!");
			System.out.println("씻고 잔다");
		} catch (Throwable e) {
			//e.printStackTrace();
			System.out.println("119에 신고!");
		} 
		System.out.println("문을 잠그고 집을 나간다.");
	}
}










