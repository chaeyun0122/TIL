package aop03;

public interface Calculator {
	public long factorial(long n);
}
