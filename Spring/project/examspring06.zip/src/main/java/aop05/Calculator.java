package aop05;

public interface Calculator {
	public long factorial(long n);
}
