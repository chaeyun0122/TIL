package aop015;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.core.annotation.Order;

@Aspect
@Order(10)
public class MyAspect {
	
	@Pointcut("execution(* runSomething())")
	public void pc() {}
	
	@Before("pc()")
	public void openIn(JoinPoint pjp) {
		System.out.println("문을 열고 집에 들어간다.");
	}
	
	@After("pc()")
	public void closeOut(JoinPoint pjp) {
		System.out.println("문을 닫고 집을 나간다.");
	}
	
//	@Around("pc()")
//	public void life(ProceedingJoinPoint pjp) {
//		System.out.println("문을 열고 집에 들어간다.");
//		try {
//			System.out.println("씻는다.");
//			pjp.proceed();
//			System.out.println("양치한다.");
//		} catch (Throwable e) {
//			e.printStackTrace();
//		}
//		System.out.println("문을 닫고 집을 나간다.");
//	}
	
}










