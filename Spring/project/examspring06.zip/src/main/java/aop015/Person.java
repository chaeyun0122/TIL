package aop015;

public interface Person {
	public void runSomething();
}
