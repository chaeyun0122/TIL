package aop015;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.core.annotation.Order;

@Aspect
@Order(20)
public class MyAspect2 {
	
	@Pointcut("execution(* runSomething())")
	public void pc() {}
	
	@Before("pc()")
	public void openIn(JoinPoint pjp) {
		System.out.println("중문을 열고 집에 들어간다.");
	}
	
	@After("pc()")
	public void closeOut(JoinPoint pjp) {
		System.out.println("중문을 닫고 집을 나간다.");
	}
	
//	@Around("pc()")
//	public void life(ProceedingJoinPoint pjp) {
//		System.out.println("중문을 열고 집에 들어간다.");
//		try {
//			System.out.println("밥은 먹는다.");
//			pjp.proceed();
//			System.out.println("잔다.");
//		} catch (Throwable e) {
//			e.printStackTrace();
//		}
//		System.out.println("중문을 닫고 집을 나간다.");
//	}
}










