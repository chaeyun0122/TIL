package aop04;

public interface Calculator {
	public long factorial(long n);
}
