package aop002;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;

@Aspect
public class MyAspect {
	
//	@Before("execution(public void aop002.Boy.runSomething()) || execution(public void aop002.Girl.runSomething())") // AOP 표현식

//	@Before("execution(public void aop002.*.runSomething())")
	
	@Before("execution(public void aop002..runSomething())")
	public void beforeMethod() {
		System.out.println("문을 열고 집에 들어간다.");
	}
	
	
//	@Before("execution(public void aop002..runSomething())")
//	public void beforeMethod1(JoinPoint jp) {
//		System.out.println("문을 열고 집에 들어간다.");
//		
//		System.out.println(jp.getKind()); // 함수에 대한 
//		System.out.println(jp.getTarget()); // joinpoint한 객체
//		System.out.println(jp.getThis());
//		System.out.println(jp.getArgs()); // 핵심 메서드에 전달된 인자 확인
//		System.out.println(jp.getSignature());
//		System.out.println(jp.getSourceLocation());
//	}
	
	/*
	 * JoinPoint란 핵심 함수가 실행하기 전, 중간, 후 등의 포인트다.
	 * PointCut은 그 JoinPoint들 중 공통 함수가 자르고 들어갈 곳이다.
	 * Advice는 그 PointCut을 기준으로 어느 시점에 실행 될 것인지 나타낸다. (여기서는 @Before이므로 이전)
	 * 메서드에 JoinPoint를 인자로 받으면 main에서 pointcut 함수가 실행될 때 받는 인자가 있다면
	 * joinpoint가 그 인자를 받는다.
	 */
	
	// JoinPoint의 인자를 받는 경우
	@Before("execution(public void aop002..runSomething(int, float))")
	public void beforeMethod2(JoinPoint jp) {
		System.out.println("문을 열고 집에 들어간다.");
		
		Object[] args = jp.getArgs();
		for (int i = 0; i < args.length; i++) {
			System.out.println(args[i]);
		}
	}
}

/*
 * 포인트 컷 지시자(표현식)
 * 	execution([접근 제한자] 반환자료형 [패키지명.][클래스명].메서드명(파라미터타입))
 * 
 * 	* : 모든 값
 * 	.. : 0 개 이상
 * 
 * 		import java.util.*
 * 
 * 		java.util.Random		( O )
 * 		java.util.Scanner		( O )
 * 		java.util.other.Test	( x ) 하위 패키지까지 선택되지 않음
 */
