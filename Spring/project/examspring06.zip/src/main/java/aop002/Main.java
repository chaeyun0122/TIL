package aop002;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {
	public static void main(String[] args) {
		ApplicationContext ctx = 
				new ClassPathXmlApplicationContext("aop002.xml");
		
		// Boy romeo = ctx.getBean("boy", Boy.class);가 오류나는 이유
		// 인터페이스 기반으로 가기 때문에 Person으로 해야한다.
		Person romeo = ctx.getBean("boy", Person.class);
		Person juliet = ctx.getBean("girl", Person.class);
		
		romeo.runSomething();
		System.out.println();
		juliet.runSomething();
		System.out.println("=================");
		romeo.runSomething(10, 3.14f);
		System.out.println();
		juliet.runSomething(20, 6.28f);
	}
}
