package aop002;

public interface Person {
	public void runSomething();
	public void runSomething(int a, float b);
}
