package aop004;

public interface Person {
	public void runSomething();
}
