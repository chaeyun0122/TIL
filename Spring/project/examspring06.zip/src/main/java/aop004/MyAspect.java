package aop004;

import org.aspectj.lang.JoinPoint;

// POJO 클래스
public class MyAspect {
	public void OpenIn(JoinPoint jp) {
		System.out.println("문을 열고 집에 들어간다.");
	}
	
	public void LockOut(JoinPoint jp) {
		System.out.println("문을 잠그고 집을 나간다.");
	}
}
