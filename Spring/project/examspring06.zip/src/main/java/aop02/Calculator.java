package aop02;

public interface Calculator {
	public long factorial(long n);
}
