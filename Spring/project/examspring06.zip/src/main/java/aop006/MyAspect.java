package aop006;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;

@Aspect
public class MyAspect {
	
	@Pointcut("execution(* runSomething())")
	public void pc() {}
	
	@Before("pc()")
	public void OpenIn(JoinPoint jp) {
		System.out.println("문을 열고 집에 들어간다.");
	}
	
	@After("pc()")
	public void LockOut(JoinPoint jp) {
		System.out.println("문을 잠그고 집을 나간다.");
	}
}
