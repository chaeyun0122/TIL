package exam2;

public class 입출금로그 implements 은행업무{
	private 은행업무 업무;
	
	public 입출금로그(은행업무 업무) {
		this.업무 = 업무;
	}
	
	@Override
	public void process() {
		System.out.println(업무 + "로그");
		업무.process();
	}
}
