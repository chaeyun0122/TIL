package exam2;

public class 입금 implements 은행업무{
	public void process() {
		System.out.println("입금되었습니다.");
	}
}
