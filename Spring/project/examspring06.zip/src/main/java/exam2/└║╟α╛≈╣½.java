package exam2;

public interface 은행업무 {
	public void process();
}
