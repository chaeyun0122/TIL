package exam2;

public class Ex01 {
	public static void main(String[] args) {
		입출금로그 in = new 입출금로그(new 입금());
		입출금로그 out = new 입출금로그(new 출금());
		
		in.process();
		out.process();
	}
}
