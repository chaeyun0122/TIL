package exam2;

public class 출금 implements 은행업무{
	public void process() {
		System.out.println("출금되었습니다.");
	}
}
