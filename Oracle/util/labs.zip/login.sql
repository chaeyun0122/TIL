set pagesize 1000
set linesize 150 
set timing on
set feedback 1
set sqlprompt "_user'@'_connect_identifier> "
